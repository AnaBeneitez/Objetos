
package tpobjetos;

public class TpObjetos {

    public static void main(String[] args) {
        Menu agenda = new Menu();
        agenda.mostrarMenu();
    }
    
}
